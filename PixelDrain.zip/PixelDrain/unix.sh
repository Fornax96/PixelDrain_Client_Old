#!/bin/sh
java -jar PixelDrain.jar
