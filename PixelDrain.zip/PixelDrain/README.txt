Hello,
To run PixelDrain, run the SHELL or BATCH file for your system.
There are more instructions in the GUI

 - Wim Brand
